import 'package:flutter/material.dart';

void main() {
  runApp(new Projeto());
}

class Projeto extends StatelessWidget {
  Image img = Image.asset('assets/marlin.jpg');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
//-------------------------------------------------------------------- Appbar
        appBar: AppBar(
            title: const Text(
              "Teste de Imagem",
              style: TextStyle(fontSize: 25),
            ),
            foregroundColor: Colors.white,
            backgroundColor: Color.fromARGB(255, 71, 71, 71),
            centerTitle: true),

//-------------------------------------------------------------------- Body
        body: Column(
//-------------------------------------------------------------------- Imagem e Texto
          children: [
            Container(
              child: Image(image: img.image),
            ),
            Container(
                child: (const Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  "Marilyn Monroe",
                ),
                Text(
                  "Atriz",
                )
              ],
            ))),
//-------------------------------------------------------------------- Fileira com os botões
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Expanded(
                    child: ElevatedButton(
                  onPressed: () => print("Botão 1 clicado!"),
                  child: Text("Linda"),
                )),
                Expanded(
                    child: ElevatedButton(
                  onPressed: () => print("Botão 1 clicado!"),
                  child: Text("Linda"),
                )),
                Expanded(
                    child: ElevatedButton(
                  onPressed: () => print("Botão 1 clicado!"),
                  child: Text("Linda"),
                )),
              ],
            )
          ],
        ),
      ),
    );
  }
}
